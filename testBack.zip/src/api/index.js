import ajax from "./ajax";
const BASE = 'http://1.14.132.157:3880'

// 登录接口
export const reqLogin = (data) => ajax('https://yc.jsrunning.club/login', data, 'POST', { headers:{"Content-Type": "application/x-www-form-urlencoded"}})

// 所有学生信息
export const reqAllStu = () => ajax(BASE + '/student/getAll', 'GET')
