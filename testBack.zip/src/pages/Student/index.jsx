import React, { Component } from 'react'
import {reqAllStu} from '../../api'

export default class index extends Component {

  constructor(props) {
    super(props)
    this.state = {
      stuInfo: []
    }
  }
  
  componentDidMount = async() => {
    const student = await reqAllStu()
    console.log(student)
  }

  render() {
    return (
      <div>
        学生
      </div>
    )
  }
}
