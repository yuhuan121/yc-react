/*
用于在内存中保存数据的工具模块
*/
export default{
  user:{},
}